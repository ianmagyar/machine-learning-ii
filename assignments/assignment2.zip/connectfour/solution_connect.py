# your solution goes here, import whatever you need


class StudentAgent:
    def __init__(self, code=1):
        # add any parameters you want
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        """
        implement the act function here, it returns a single integer value:
        the column where the player puts his mark:
        """
        pass

    def load_agent(self, path):
        # the system loads a trained agent from the given file path
        pass
