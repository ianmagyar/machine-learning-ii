from itertools import groupby, chain

import numpy as np


def diagonalsPos(matrix, cols, rows):
    """Get positive diagonals, going from bottom-left to top-right."""
    for di in ([(j, i - j) for j in range(cols)] for i in range(cols + rows -1)):
        yield [matrix[i][j] for i, j in di if i >= 0 and j >= 0 and i < cols and j < rows]


def diagonalsNeg(matrix, cols, rows):
    """Get negative diagonals, going from top-left to bottom-right."""
    for di in ([(j, i - cols + j + 1) for j in range(cols)] for i in range(cols + rows - 1)):
        yield [matrix[i][j] for i, j in di if i >= 0 and j >= 0 and i < cols and j < rows]


class ConnectFour:
    def __init__(self):
        self.cols = 7
        self.rows = 6
        self.toWin = 4

        self.reset()

    def reset(self):
        self.board = np.full((self.cols, self.rows), '.', dtype='str')
        return self.get_state()

    def get_state(self):
        return self.board

    def has_won(self):
        lines = (
            self.board,  # columns
            zip(*self.board),  # rows
            diagonalsPos(self.board, self.cols, self.rows),  # positive diags
            diagonalsNeg(self.board, self.cols, self.rows)  # negative diags
        )

        for line in chain(*lines):
            for code, group in groupby(line):
                if code != '.' and len(list(group)) >= self.toWin:
                    return code

        return 0

    def is_done(self):
        if self.has_won() != 0:
            return True

        # otherwise check if there are valid actions
        return len(self.get_valid_actions()) == 0

    def get_reward(self, player, wins):
        # returns 1 if player wins
        # -1 if player loses
        # 0 otherwise
        if wins != 0:
            return player == wins

        return 0

    def step(self, action, player='R'):
        # takes player action, and enacts it
        # puts the color on top of the given column
        c = self.board[action]

        if c[0] != '.':
            raise ValueError("Column {} is full!".format(action))

        i = -1
        while c[i] != '.':
            i -= 1

        orig_grid = self.board.copy()
        c[i] = player

        done = self.is_done()
        reward = self.get_reward(player, self.has_won())

        string = "Placed marker of player {} in column {}".format(
            player, action)

        info = {
            "state1": orig_grid,
            "action": action,
            "state2": self.board.copy(),
            "reward": reward,
            "done": done,
            "string": string
        }

        return self.get_state(), reward, done, info

    def get_valid_actions(self):
        # returns a list of valid actions (columns with empty space)
        return [i for i in range(self.cols) if self.board[i][0] == '.']

    def print_board(self):
        """Print the board."""
        print('  '.join(map(str, range(self.cols))))
        for y in range(self.rows):
            print('  '.join(str(self.board[x][y]) for x in range(self.cols)))
        print()
