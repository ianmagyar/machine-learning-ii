from connectfour import ConnectFour

import random


def would_win(board, action, code):
    test = ConnectFour()
    test.board = board.copy()

    test.step(action, code)

    return test.has_won() == code


class RandomBot:
    def __init__(self, code='R'):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # select action randomly from empty places
        valid = [i for i in range(7) if state[i][0] == '.']
        return random.choice(valid)


class OneStepBot:
    def __init__(self, code='R'):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # find empty places
        valid_actions = [i for i in range(7) if state[i][0] == '.']

        # if any action leads to win, make it, otherwise select randomly
        for i in valid_actions:
            if would_win(state, i, self.player_code):
                return i

        return random.choice(valid_actions)


class TwoStepBot:
    def __init__(self, code='R'):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # find empty places
        valid_actions = [i for i in range(7) if state[i][0] == '.']
        opp_code = 'R' if self.player_code == 'Y' else 'Y'

        # if any action leads to win, make it, otherwise select randomly
        for i in valid_actions:
            if would_win(state, i, self.player_code):
                return i

            test = ConnectFour()
            test.board = state.copy()
            new_board, _, _, _ = test.step(i, self.player_code)

            new_valid = [i for i in range(7) if new_board[i][0] == '.']
            for j in new_valid:
                if would_win(new_board, j, opp_code):
                    return j

        return random.choice(valid_actions)
