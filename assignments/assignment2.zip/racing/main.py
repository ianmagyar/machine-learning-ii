from bots import RandomBot, SmartBot, SmarterBot
from racing import Racing


if __name__ == '__main__':

    track = Racing()
    player_1 = RandomBot(code=1)
    player_2 = RandomBot(code=-1)

    one_wins = 0
    two_wins = 0
    both_wins = 0
    dnfs = 0
    TESTS = 1000

    for _ in range(TESTS):
        track.reset()

        while not track.is_done():
            state = track.get_state().copy()

            # get player moves
            p1_move = player_1.act(state)
            p2_move = player_2.act(state)

            new_state, reward, done, info = track.step(p1_move, p2_move)

        result = track.has_won()
        if result == 3:
            both_wins += 1
        if result == 1:
            one_wins += 1
        elif result == -1:
            two_wins += 1
        else:
            dnfs += 1

    print("{} runs: {} player 1 wins ({:.2f}%); {} player 2 wins ({:.2f}%); {} ties ({:.2f}%); {} DNFs ({:.2f}%)".format(
        TESTS,
        one_wins, 100 * one_wins / TESTS,
        two_wins, 100 * two_wins / TESTS,
        both_wins, 100 * both_wins / TESTS,
        dnfs, 100 * dnfs / TESTS))
