from bots import RandomBot, OneStepBot, TwoStepBot
from tictactoe import TicTacToe


if __name__ == '__main__':

    board = TicTacToe()
    player_1 = OneStepBot(code=1)
    player_2 = RandomBot(code=-1)

    one_wins = 0
    two_wins = 0
    ties = 0
    TESTS = 1000

    for _ in range(TESTS):
        board.reset()
        while not board.isDone():
            # player 1 makes a move
            state = board.get_state().copy()
            p1_action = player_1.act(state)
            new_state, reward, done, info = board.step(p1_action, player_1.get_code())
            # print("Player 1 places sign at {}: {} -> {}".format(
            #     p1_action, state, new_state))

            if board.isDone():
                break

            state = new_state.copy()
            p2_action = player_2.act(state)
            new_state, reward, done, info = board.step(p2_action, player_2.get_code())
            # print("Player 2 places sign at {}: {} -> {}".format(
            #     p2_action, state, new_state))

        result = board.has_won()
        if result == 1:
            one_wins += 1
        elif result == -1:
            two_wins += 1
        else:
            ties += 1

    print("{} runs: {} player 1 wins ({:.2f}%); {} player 2 wins ({:.2f}%); {} ties ({:.2f}%)".format(
        TESTS,
        one_wins, 100 * one_wins / TESTS,
        two_wins, 100 * two_wins / TESTS,
        ties, 100 * ties / TESTS))
