import numpy as np


def pos_to_char(pos):
    # you can use this function for printing the board
    return '.' if pos == 0 else 'O' if pos == 1 else 'X'


class TicTacToe:
    def __init__(self):
        self.size = 3
        self.reset()

        self.length = 3

    def reset(self):
        self.grid = np.zeros((self.size, self.size), dtype='int')
        return self.get_state()

    def add_sign(self, row, col, number):
        # places a sign at the given position
        # returns True if the sign was placed
        # returns False if the position was already taken
        if self.grid[row][col] == 0:
            self.grid[row][col] = number
            return True
        return False

    def add_player1(self, row, col):
        self.add_sign(row, col, 1)

    def add_player2(self, row, col):
        self.add_sign(row, col, -1)

    def has_won(self):
        # returns the code of the player who has won
        # returns 0 if the game hasn't yet been won

        # check lines
        for row in range(0, self.size):
            check_row = self.grid[row]
            if check_row[0] == check_row[1] == check_row[2]:
                return check_row[0]

        # check cols
        for col in range(0, self.size):
            check_col = self.grid[:, col]
            if check_col[0] == check_col[1] == check_col[2]:
                return check_col[0]

        # check main diagonal
        if self.grid[0][0] == self.grid[1][1] == self.grid[2][2]:
            return self.grid[1][1]

        # check other diagonal
        if self.grid[2][0] == self.grid[1][1] == self.grid[0][2]:
            return self.grid[1][1]

        return 0

    def isDone(self):
        # checks if the game is over:
        # it has been won or there are no empty places left

        # if someone won, end of game
        if self.has_won() != 0:
            return True

        # otherwise check if there are zeroes in the grid left
        return np.count_nonzero(self.grid == 0) == 0

    def get_state(self):
        # returns the board as an array with dimensions 1x9
        return self.grid.reshape((1, 9))

    def get_reward(self):
        # 1 if player 1 wins
        # -1 if player 2 wins (player 1 loses)
        # 0 for draw or otherwise
        return self.has_won()

    def step(self, action, player=1):
        # takes player action, and enacts it
        # the sign is placed only if the position was empty

        if action >= self.size ** 2 or action < 0:
            raise ValueError(
                "Trying to play undefined position {}".format(action))

        if player == 1:
            add_func = self.add_player1
            sign = 1
        else:
            add_func = self.add_player2
            sign = -1

        orig_grid = self.grid.copy()

        row = action // self.size
        col = action % self.size

        success = add_func(row, col)
        reward = self.get_reward()
        done = self.isDone()

        if success:
            string = "Placed {} on position [{}, {}]".format(sign, row, col)
        else:
            string = "Invalid {} to position [{}, {}]".format(sign, row, col)

        info = {
            "state1": orig_grid,
            "action": action,
            "state2": self.grid.copy(),
            "reward": reward,
            "done": done,
            "string": string
        }

        return self.get_state(), reward, done, info

    def get_valid_actions(self):
        # returns a list of valid actions (empty positions)
        valid_actions = list()
        for i in range(self.size ** 2):
            row = i / self.size
            col = i % self.size
            if self.grid[row][col] == 0:
                valid_actions.append(i)

        return valid_actions
