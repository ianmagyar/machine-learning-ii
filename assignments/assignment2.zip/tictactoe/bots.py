from copy import deepcopy

import numpy as np


def would_win(board):
    for row in range(0, board.shape[0]):
        check_row = board[row]
        if check_row[0] == check_row[1] == check_row[2]:
            return check_row[0]

    # check cols
    for col in range(0, board.shape[1]):
        check_col = board[:, col]
        if check_col[0] == check_col[1] == check_col[2]:
            return check_col[0]

    # check main diagonal
    if board[0][0] == board[1][1] == board[2][2]:
        return board[1][1]

    # check other diagonal
    if board[2][0] == board[1][1] == board[0][2]:
        return board[1][1]

    return 0


class RandomBot:
    def __init__(self, code=1):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # select action randomly from empty places
        valid_actions = np.where(state[0] == 0)[0]
        action = np.random.choice(valid_actions.shape[0], 1)[0]

        return valid_actions[action]


class OneStepBot:
    def __init__(self, code=1):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # find empty places
        valid_actions = np.where(state[0] == 0)[0]

        # if any action leads to win, make it, otherwise select randomly
        for i in valid_actions:
            new_board = state.copy()
            new_board[0][i] = self.player_code
            new_board = new_board.reshape((3, 3))
            if would_win(new_board) == self.player_code:
                return i

        action = np.random.choice(valid_actions.shape[0], 1)[0]
        return valid_actions[action]


class TwoStepBot:
    def __init__(self, code=1):
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        # find empty places
        valid_actions = np.where(state[0] == 0)[0]
        losing_move = None

        for i in valid_actions:
            # if can win with one move, select it
            new_board = state.copy()
            new_board[0][i] = self.player_code
            new_board = new_board.reshape((3, 3))
            if would_win(new_board) == self.player_code:
                return i

            # block opponent's next winning move
            new_state = new_board.reshape((1, 9))
            # print("{} - {} -> {}".format(state, i, new_state))
            new_valid_actions = np.where(new_state[0] == 0)[0]
            for j in new_valid_actions:
                final_board = new_state.copy()
                final_board[0][j] = -1 * self.player_code
                final_board = final_board.reshape((3, 3))
                if would_win(final_board) == -1 * self.player_code:
                    # print("blocking:")
                    # print("{} - {} -> {}".format(new))
                    losing_move = j

        # if there is a way to lose the game with a bad move, prevent it
        if losing_move is not None:
            return losing_move

        action = np.random.choice(valid_actions.shape[0], 1)[0]
        return valid_actions[action]
