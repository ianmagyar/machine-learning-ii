# your solution goes here, import whatever you need


class StudentAgent:
    def __init__(self, code=1):
        # add any parameters you want
        self.player_code = code

    def get_code(self):
        return self.player_code

    def act(self, state):
        """
        implement the act function here, it returns a single integer value:
        the position where the player puts his mark:
        #######
        #0#1#2#
        #3#4#5#
        #6#7#8#
        #######
        """
        pass

    def load_agent(self, path):
        # the system loads a trained agent from the given file path
        pass
