import numpy as np

from gridworld import *


class MonteCarloAgent:
    def __init__(self, env, gamma=0.8, epsilon=0.1):
        self.env = env
        self.discount_factor = gamma
        self.epsilon = epsilon

        self.init_helpers()

    def init_helpers(self):
        self.N_STATES = self.env.width * self.env.height
        self.N_ACTIONS = 4
        self.policy = np.full((self.N_STATES, self.N_ACTIONS), 0.25)
        self.Q = np.zeros((self.N_STATES, self.N_ACTIONS))
        self.returns = dict()

    def propose_action(self, state):
        probs = self.policy[state]
        return np.random.choice(np.arange(self.N_ACTIONS), p=probs)

    def generate_episode(self):
        steps = list()
        state = self.env.reset()
        done = False
        while not done:
            action = self.propose_action(state)
            next_state, reward, done, _ = self.env.step(action)
            steps.append((state, action, reward))
            state = next_state

        return steps

    def train_on_episode(self, episode):
        G = 0.0
        for i in reversed(range(len(episode))):
            state, action, reward = episode[i]
            G = self.discount_factor * G + reward
            if (state, action) not in [(x[0], x[1]) for x in episode[:i]]:
                if (state, action) in self.returns:
                    self.returns[(state, action)].append(G)
                else:
                    self.returns[(state, action)] = [G]

                state_returns = self.returns[(state, action)]
                self.Q[state][action] = sum(state_returns) / len(state_returns)

                best_action = np.argmax(self.Q[state])
                self.policy[state] = self.epsilon / self.N_ACTIONS
                self.policy[state][best_action] += 1 - self.epsilon

    def train(self, episodes=10):
        for _ in range(episodes):
            episode = self.generate_episode()
            self.train_on_episode(episode)


if __name__ == '__main__':
    world = Gridworld()
    world.render()
    agent = MonteCarloAgent(world)

    agent.train(episodes=100)
    print(agent.policy)
