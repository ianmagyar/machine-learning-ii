# Source: https://michaeloneill.github.io/RL-tutorial.html

import numpy as np

from gridworld import Gridworld
from TileCoding import IHT, tiles


env = Gridworld(3, 3, goal_position=(3, 3), traps=[(2, 2)])
ACTION_COUNT = 4


class QEstimator:
    def __init__(self, step_size, num_tilings=8, max_size=4096, tiling_dim=None, trace=False):
        self.trace = trace
        self.max_size = max_size
        self.num_tilings = num_tilings
        self.tiling_dim = tiling_dim or num_tilings

        self.alpha = step_size / num_tilings
        self.iht = IHT(max_size)

        self.weights = np.zeros(max_size)
        if self.trace:
            self.z = np.zeros(max_size)

        self.y_scale = self.tiling_dim / env.height
        self.x_scale = self.tiling_dim / env.width

    def featurize_state_action(self, state, action):
        return tiles(self.iht, self.num_tilings,
                     [self.y_scale * state[0],
                      self.x_scale * state[1]],
                     [action])

    def predict(self, s, a=None):
        if a is None:
            features = [self.featurize_state_action(s, i)
                        for i in range(ACTION_COUNT)]
        else:
            features = [self.featurize_state_action(s, a)]

        return [np.sum(self.weights[f]) for f in features]

    def update(self, s, a, target):
        features = self.featurize_state_action(s, a)
        estimation = np.sum(self.weights[features])
        delta = (target - estimation)

        if self.trace:
            self.z[features] = 1
            self.weights += self.alpha * delta * self.z
        else:
            self.weights[features] += self.alpha * delta

    def reset(self, z_only=False):
        if self.trace:
            self.z = np.zeros(self.max_size)
        if not z_only:
            self.weights = np.zeros(self.max_size)


def make_epsilon_greedy_policy(estimator, epsilon, num_actions):
    def policy_fn(observation):
        action_probs = np.ones(num_actions, dtype=float) * epsilon / num_actions
        q_values = estimator.predict(observation)
        best_action_idx = np.argmax(q_values)
        action_probs[best_action_idx] += (1.0 - epsilon)
        return action_probs
    return policy_fn


def sarsa_n(n, env, estimator, gamma=0.8, epsilon=0.1):
    policy = make_epsilon_greedy_policy(estimator, epsilon, ACTION_COUNT)

    state, _ = env.reset()
    action_probs = policy(state)
    action = np.random.choice(np.arange(len(action_probs)), p=action_probs)

    trunc = False
    while not env.is_done() and not trunc:
        next_state, reward, done, trunc, _ = env.step(action)

        if env.is_done():
            estimator.update(state, action, reward)
            break
        else:
            action_probs = policy(state)
            next_action = np.random.choice(
                np.arange(len(action_probs)), p=action_probs)
            next_q_val = estimator.predict(next_state)[next_action]
            target = reward + next_q_val

            estimator.update(state, action, target)

            state = next_state
            action = next_action


step_size = 0.5
n = 1
num_episodes = 1000

estimator_n = QEstimator(step_size)

for i in range(num_episodes):
    print(i)
    sarsa_n(n, env, estimator_n)

ACTIONS = ['N', 'E', 'S', 'W']
for y in range(env.height + 1):
    for x in range(env.width + 1):
        q_vals = estimator_n.predict((y, x))
        action = ACTIONS[np.argmax(q_vals)]
        print(f"State ({y}, {x}): {q_vals} -> action: {action}")
