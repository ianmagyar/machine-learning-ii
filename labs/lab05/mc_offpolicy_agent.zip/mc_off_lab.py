import numpy as np

from gridworld import *


class MonteCarloAgent:
    def __init__(self, env, gamma=0.8, epsilon=0.1):
        self.env = env
        self.discount_factor = gamma
        self.epsilon = epsilon

        self.init_helpers()

    def init_helpers(self):
        self.N_STATES = self.env.width * self.env.height
        self.N_ACTIONS = 4
        self.Q = np.random.rand(self.N_STATES, self.N_ACTIONS)
        self.C = np.zeros((self.N_STATES, self.N_ACTIONS))
        self.policy = np.argmax(self.Q, axis=1)

    def propose_action(self, state):
        return self.policy[state]

    def propose_action_b(self, state, policy_b):
        probs = policy_b[state]
        return np.random.choice(np.arange(self.N_ACTIONS), p=probs)

    def generate_episode(self, policy_b):
        steps = list()
        state, _ = self.env.reset()
        done = False
        while not done:
            action = self.propose_action_b(state, policy_b)
            next_state, reward, done, truncated, _ = self.env.step(action)
            steps.append((state, action, reward))
            state = next_state

        return steps

    def train_on_episode(self, episode, policy_b):
        G = 0.0
        W = 1.0
        for i in reversed(range(len(episode))):
            state, action, reward = episode[i]
            G = self.discount_factor * G + reward
            self.C[state, action] += W
            print((W / self.C[state, action]))
            print((G - self.Q[state, action]))
            self.Q[state, action] += (W / self.C[state, action]) * (G - self.Q[state, action])
            self.policy[state] = np.argmax(self.Q[state])
            print(i)
            print(self.Q)
            print(self.C)
            print(self.policy)
            if action != self.policy[state]:
                print("Stopped processing at step {} out of {}".format(i + 1, len(episode)))
                break
            W *= (1 / policy_b[state, action])
            print("W", W)
        else:
            print("Processed whole")

    def train(self, episodes=10):
        policy_b = np.full((self.N_STATES, self.N_ACTIONS), 1 / self.N_ACTIONS)

        # for epsilon-greedy
        epsilon = 0.1
        # policy_b = np.full((self.N_STATES, self.N_ACTIONS), epsilon / self.N_ACTIONS)
        # for row in policy_b:
        #     row[np.random.randint(0, self.N_ACTIONS)] += (1 - epsilon)
        for _ in range(episodes):
            episode = self.generate_episode(policy_b)
            self.train_on_episode(episode, policy_b)


if __name__ == '__main__':
    world = Gridworld()
    agent = MonteCarloAgent(world)

    start = np.array([
        [0.6, 0.7, 0.2, 0.9],
        [0.3, 0.9, 0.5, 0.4],
        [0.6, 0.7, 0.1, 0.0],
        [0.9, 0.5, 0.1, 0.1],
        [0.1, 0.2, 0.6, 0.7],
        [0.7, 0.6, 0.5, 0.4],
        [0.9, 0.2, 0.3, 0.7],
        [0.9, 0.6, 0.4, 0.1],
        [0.9, 0.5, 0.4, 0.1]
    ])
    agent.Q = start
    agent.policy = np.argmax(agent.Q, axis=1)

    print(agent.Q)
    print(agent.policy)

    policy_b = np.full((9, 4), 1 / 4)
    ep1 = [(8, 1, -1.0), (8, 2, -1.0), (8, 1, -1.0), (8, 0, -1.0), (5, 1, -1.0), (5, 0, 10.0)]
    ep2 = [(3, 2, -1.0), (6, 1, 5.0), (7, 2, -1.0), (7, 0, -10.0)]
    ep3 = [(6, 1, -1.0), (7, 1, -1.0), (8, 0, -1.0), (5, 0, 10.0)]
    agent.train_on_episode(ep1, policy_b)
    print()
    agent.train_on_episode(ep2, policy_b)
    print()
    agent.train_on_episode(ep3, policy_b)
